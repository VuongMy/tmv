
var $ = require("jquery");

   